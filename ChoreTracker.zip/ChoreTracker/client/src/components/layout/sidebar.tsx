import { Link, useLocation } from "wouter";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

interface SidebarProps {
  mobile?: boolean;
}

export default function Sidebar({ mobile = false }: SidebarProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const navItems = [
    { path: "/dashboard", label: "Dashboard", icon: "dashboard" },
    { path: "/tasks", label: "Tasks", icon: "assignment" },
    { path: "/roommates", label: "Roommates", icon: "group" },
    { path: "/schedule", label: "Schedule", icon: "event" },
    { path: "/statistics", label: "Statistics", icon: "equalizer" },
    { path: "/settings", label: "Settings", icon: "settings" },
  ];
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  if (!user) return null;
  
  return (
    <div className={cn(
      "flex flex-col bg-white shadow-lg",
      mobile ? "h-full" : "hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0"
    )}>
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex items-center justify-center h-16 bg-primary text-white">
          <span className="text-xl font-bold">RoommateChore</span>
        </div>
        
        <nav className="flex-1 px-2 py-4 bg-white space-y-1">
          {navItems.map((item) => {
            const isActive = location === item.path;
            
            return (
              <Link 
                key={item.path}
                href={item.path}
                className={cn(
                  "group flex items-center px-2 py-3 text-sm font-medium rounded-md",
                  isActive 
                    ? "bg-primary bg-opacity-10 text-primary" 
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                )}
              >
                <span className={cn(
                  "material-icons mr-3",
                  isActive 
                    ? "text-primary" 
                    : "text-gray-400 group-hover:text-gray-500"
                )}>
                  {item.icon}
                </span>
                {item.label}
              </Link>
            );
          })}
        </nav>
        
        {/* User Info */}
        <div className="flex flex-col p-4 border-t border-gray-200">
          <div className="flex items-center">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              {user.firstName.charAt(0)}{user.lastName ? user.lastName.charAt(0) : ''}
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-700">{user.firstName} {user.lastName || ''}</p>
              <p className="text-xs text-gray-500">{user.email}</p>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
            className="mt-3 justify-start text-gray-600 hover:text-gray-900 hover:bg-gray-50"
          >
            <LogOut className="h-4 w-4 mr-2" />
            {logoutMutation.isPending ? "Logging out..." : "Logout"}
          </Button>
        </div>
      </div>
    </div>
  );
}
