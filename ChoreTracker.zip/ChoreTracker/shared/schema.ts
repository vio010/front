import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("firstName").notNull(),
  lastName: text("lastName"),
  email: text("email").notNull(),
  avatar: text("avatar"),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Households table
export const households = pgTable("households", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const insertHouseholdSchema = createInsertSchema(households).omit({
  id: true,
  createdAt: true,
});

// User-Household relationship (many-to-many)
export const userHouseholds = pgTable("userHouseholds", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull().references(() => users.id),
  householdId: integer("householdId").notNull().references(() => households.id),
  isAdmin: boolean("isAdmin").default(false),
  joinedAt: timestamp("joinedAt").defaultNow(),
});

export const insertUserHouseholdSchema = createInsertSchema(userHouseholds).omit({
  id: true,
  joinedAt: true,
});

// Tasks (chores) table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  householdId: integer("householdId").notNull().references(() => households.id),
  assignedToId: integer("assignedToId").references(() => users.id),
  createdById: integer("createdById").notNull().references(() => users.id),
  dueDate: timestamp("dueDate"),
  completed: boolean("completed").default(false),
  completedAt: timestamp("completedAt"),
  completedById: integer("completedById").references(() => users.id),
  recurring: text("recurring"), // "never", "daily", "weekly", "monthly"
  sendReminder: boolean("sendReminder").default(true),
  createdAt: timestamp("createdAt").defaultNow(),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  completedAt: true,
  completedById: true,
  createdAt: true,
});

// Activities table for tracking room mate activities
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull().references(() => users.id),
  householdId: integer("householdId").notNull().references(() => households.id),
  type: text("type").notNull(), // "task_completed", "task_created", "task_assigned"
  taskId: integer("taskId").references(() => tasks.id),
  metadata: json("metadata"), // Additional activity details
  createdAt: timestamp("createdAt").defaultNow(),
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertHousehold = z.infer<typeof insertHouseholdSchema>;
export type Household = typeof households.$inferSelect;

export type InsertUserHousehold = z.infer<typeof insertUserHouseholdSchema>;
export type UserHousehold = typeof userHouseholds.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
