import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema, insertUserSchema, insertHouseholdSchema, insertUserHouseholdSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { setupAuth } from "./auth";

// Authentication middleware
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);
  
  // We'll enable route protection later when we have the frontend ready
  // For now, we'll allow all routes to work without authentication
  /* 
  const authRoutes = [
    "/api/households",
    "/api/user-households",
    "/api/tasks",
  ];
  
  app.use(authRoutes, isAuthenticated);
  */
  
  // User endpoints
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        avatar: user.avatar
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });
  
  // Household endpoints
  app.post("/api/households", async (req: Request, res: Response) => {
    try {
      const householdData = insertHouseholdSchema.parse(req.body);
      const household = await storage.createHousehold(householdData);
      res.status(201).json(household);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create household" });
    }
  });
  
  app.get("/api/households", async (_req: Request, res: Response) => {
    try {
      const households = await storage.getHouseholds();
      res.json(households);
    } catch (error) {
      res.status(500).json({ message: "Failed to get households" });
    }
  });
  
  app.get("/api/households/:id", async (req: Request, res: Response) => {
    try {
      const householdId = parseInt(req.params.id);
      
      if (isNaN(householdId)) {
        return res.status(400).json({ message: "Invalid household ID" });
      }
      
      const household = await storage.getHousehold(householdId);
      
      if (!household) {
        return res.status(404).json({ message: "Household not found" });
      }
      
      res.json(household);
    } catch (error) {
      res.status(500).json({ message: "Failed to get household" });
    }
  });
  
  // User-Household relationship endpoints
  app.post("/api/user-households", async (req: Request, res: Response) => {
    try {
      const userHouseholdData = insertUserHouseholdSchema.parse(req.body);
      const userHousehold = await storage.addUserToHousehold(userHouseholdData);
      res.status(201).json(userHousehold);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to add user to household" });
    }
  });
  
  app.get("/api/users/:userId/households", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const userHouseholds = await storage.getUserHouseholds(userId);
      res.json(userHouseholds);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user households" });
    }
  });
  
  app.get("/api/households/:householdId/users", async (req: Request, res: Response) => {
    try {
      const householdId = parseInt(req.params.householdId);
      
      if (isNaN(householdId)) {
        return res.status(400).json({ message: "Invalid household ID" });
      }
      
      const householdUsers = await storage.getHouseholdUsers(householdId);
      res.json(householdUsers);
    } catch (error) {
      res.status(500).json({ message: "Failed to get household users" });
    }
  });
  
  // Task endpoints
  app.post("/api/tasks", async (req: Request, res: Response) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });
  
  app.get("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Failed to get task" });
    }
  });
  
  app.get("/api/households/:householdId/tasks", async (req: Request, res: Response) => {
    try {
      const householdId = parseInt(req.params.householdId);
      
      if (isNaN(householdId)) {
        return res.status(400).json({ message: "Invalid household ID" });
      }
      
      const tasks = await storage.getTasksForHousehold(householdId);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to get household tasks" });
    }
  });
  
  app.get("/api/users/:userId/tasks", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const tasks = await storage.getTasksForUser(userId);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user tasks" });
    }
  });
  
  app.patch("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const taskId = parseInt(req.params.id);
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      const updates = req.body;
      const updatedTask = await storage.updateTask(taskId, updates);
      
      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(updatedTask);
    } catch (error) {
      res.status(500).json({ message: "Failed to update task" });
    }
  });
  
  app.post("/api/tasks/:id/complete", async (req: Request, res: Response) => {
    try {
      const taskId = parseInt(req.params.id);
      const { userId } = req.body;
      
      if (isNaN(taskId)) {
        return res.status(400).json({ message: "Invalid task ID" });
      }
      
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }
      
      const completedTask = await storage.completeTask(taskId, userId);
      
      if (!completedTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(completedTask);
    } catch (error) {
      res.status(500).json({ message: "Failed to complete task" });
    }
  });
  
  // Activity endpoints
  app.get("/api/households/:householdId/activities", async (req: Request, res: Response) => {
    try {
      const householdId = parseInt(req.params.householdId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      if (isNaN(householdId)) {
        return res.status(400).json({ message: "Invalid household ID" });
      }
      
      const activities = await storage.getActivitiesForHousehold(householdId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to get household activities" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
