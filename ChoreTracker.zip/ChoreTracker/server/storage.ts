import { 
  users, User, InsertUser, 
  households, Household, InsertHousehold,
  userHouseholds, UserHousehold, InsertUserHousehold,
  tasks, Task, InsertTask,
  activities, Activity, InsertActivity
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Session store
  sessionStore: session.Store;
  // User related methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Household related methods
  getHousehold(id: number): Promise<Household | undefined>;
  getHouseholds(): Promise<Household[]>;
  createHousehold(household: InsertHousehold): Promise<Household>;
  
  // UserHousehold related methods
  getUserHouseholds(userId: number): Promise<(UserHousehold & { household: Household })[]>;
  getHouseholdUsers(householdId: number): Promise<(UserHousehold & { user: User })[]>;
  addUserToHousehold(userHousehold: InsertUserHousehold): Promise<UserHousehold>;
  
  // Task related methods
  getTask(id: number): Promise<Task | undefined>;
  getTasksForHousehold(householdId: number): Promise<Task[]>;
  getTasksForUser(userId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<Task>): Promise<Task | undefined>;
  completeTask(id: number, userId: number): Promise<Task | undefined>;
  
  // Activity related methods
  getActivitiesForHousehold(householdId: number, limit?: number): Promise<(Activity & { user: User })[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private households: Map<number, Household>;
  private userHouseholds: Map<number, UserHousehold>;
  private tasks: Map<number, Task>;
  private activities: Map<number, Activity>;
  
  private userId: number;
  private householdId: number;
  private userHouseholdId: number;
  private taskId: number;
  private activityId: number;

  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.households = new Map();
    this.userHouseholds = new Map();
    this.tasks = new Map();
    this.activities = new Map();
    
    this.userId = 1;
    this.householdId = 1;
    this.userHouseholdId = 1;
    this.taskId = 1;
    this.activityId = 1;
    
    // Initialize the session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Add some initial seed data
    this.seedData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }
  
  // Household methods
  async getHousehold(id: number): Promise<Household | undefined> {
    return this.households.get(id);
  }
  
  async getHouseholds(): Promise<Household[]> {
    return Array.from(this.households.values());
  }
  
  async createHousehold(household: InsertHousehold): Promise<Household> {
    const id = this.householdId++;
    const createdAt = new Date();
    const newHousehold: Household = { ...household, id, createdAt };
    this.households.set(id, newHousehold);
    return newHousehold;
  }
  
  // UserHousehold methods
  async getUserHouseholds(userId: number): Promise<(UserHousehold & { household: Household })[]> {
    const userHouseholds = Array.from(this.userHouseholds.values())
      .filter(uh => uh.userId === userId);
    
    return userHouseholds.map(uh => {
      const household = this.households.get(uh.householdId)!;
      return { ...uh, household };
    });
  }
  
  async getHouseholdUsers(householdId: number): Promise<(UserHousehold & { user: User })[]> {
    const householdUsers = Array.from(this.userHouseholds.values())
      .filter(uh => uh.householdId === householdId);
    
    return householdUsers.map(uh => {
      const user = this.users.get(uh.userId)!;
      return { ...uh, user };
    });
  }
  
  async addUserToHousehold(userHousehold: InsertUserHousehold): Promise<UserHousehold> {
    const id = this.userHouseholdId++;
    const joinedAt = new Date();
    const newUserHousehold: UserHousehold = { ...userHousehold, id, joinedAt };
    this.userHouseholds.set(id, newUserHousehold);
    return newUserHousehold;
  }
  
  // Task methods
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async getTasksForHousehold(householdId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.householdId === householdId);
  }
  
  async getTasksForUser(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.assignedToId === userId);
  }
  
  async createTask(task: InsertTask): Promise<Task> {
    const id = this.taskId++;
    const createdAt = new Date();
    const newTask: Task = { ...task, id, createdAt };
    this.tasks.set(id, newTask);
    
    // Create activity for task creation
    await this.createActivity({
      userId: task.createdById,
      householdId: task.householdId,
      type: "task_created",
      taskId: id,
      metadata: { taskTitle: task.title }
    });
    
    return newTask;
  }
  
  async updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...updates };
    this.tasks.set(id, updatedTask);
    
    return updatedTask;
  }
  
  async completeTask(id: number, userId: number): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const completedAt = new Date();
    const updatedTask = { 
      ...task, 
      completed: true, 
      completedAt, 
      completedById: userId 
    };
    
    this.tasks.set(id, updatedTask);
    
    // Create activity for task completion
    await this.createActivity({
      userId,
      householdId: task.householdId,
      type: "task_completed",
      taskId: id,
      metadata: { taskTitle: task.title }
    });
    
    return updatedTask;
  }
  
  // Activity methods
  async getActivitiesForHousehold(householdId: number, limit: number = 10): Promise<(Activity & { user: User })[]> {
    const activities = Array.from(this.activities.values())
      .filter(activity => activity.householdId === householdId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
    
    return activities.map(activity => {
      const user = this.users.get(activity.userId)!;
      return { ...activity, user };
    });
  }
  
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.activityId++;
    const createdAt = new Date();
    const newActivity: Activity = { ...activity, id, createdAt };
    this.activities.set(id, newActivity);
    return newActivity;
  }

  // Helper method to seed initial data
  private seedData() {
    // Create users
    const users = [
      { username: 'emma', password: 'password123', firstName: 'Emma', lastName: 'Wilson', email: 'emma@example.com', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=144&h=144&q=80' },
      { username: 'alex', password: 'password123', firstName: 'Alex', lastName: 'Johnson', email: 'alex@example.com', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=144&h=144&q=80' },
      { username: 'sarah', password: 'password123', firstName: 'Sarah', lastName: 'Parker', email: 'sarah@example.com', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=144&h=144&q=80' },
      { username: 'tom', password: 'password123', firstName: 'Tom', lastName: 'Wilson', email: 'tom@example.com', avatar: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=144&h=144&q=80' }
    ];
    
    users.forEach(user => {
      const id = this.userId++;
      const createdAt = new Date();
      this.users.set(id, { ...user, id, createdAt });
    });
    
    // Create a household
    const household: InsertHousehold = {
      name: 'Apartment 4B',
      description: 'College apartment with 4 roommates'
    };
    
    const householdId = this.householdId++;
    this.households.set(householdId, { 
      ...household, 
      id: householdId, 
      createdAt: new Date() 
    });
    
    // Add users to household
    for (let userId = 1; userId <= 4; userId++) {
      const id = this.userHouseholdId++;
      this.userHouseholds.set(id, {
        id,
        userId,
        householdId,
        isAdmin: userId === 1, // Make first user an admin
        joinedAt: new Date()
      });
    }
    
    // Create tasks
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    const thursday = new Date();
    thursday.setDate(today.getDate() + (today.getDay() <= 4 ? 4 - today.getDay() : 11 - today.getDay()));
    const saturday = new Date();
    saturday.setDate(today.getDate() + (today.getDay() <= 6 ? 6 - today.getDay() : 13 - today.getDay()));
    
    // Set hours
    today.setHours(19, 0, 0, 0); // 7:00 PM
    tomorrow.setHours(17, 0, 0, 0); // 5:00 PM
    thursday.setHours(19, 0, 0, 0); // 7:00 PM
    saturday.setHours(14, 0, 0, 0); // 2:00 PM
    
    const tasks = [
      {
        title: 'Clean kitchen counters and sink',
        description: 'Wipe down all counters and clean the sink',
        householdId,
        assignedToId: 1, // Emma
        createdById: 1,
        dueDate: today,
        recurring: 'weekly',
        sendReminder: true
      },
      {
        title: 'Take out trash and recycling',
        description: 'Take all trash and recycling to the bins outside',
        householdId,
        assignedToId: 2, // Alex
        createdById: 1,
        dueDate: today,
        recurring: 'weekly',
        sendReminder: true
      },
      {
        title: 'Vacuum living room area',
        description: 'Vacuum the entire living room including under furniture',
        householdId,
        assignedToId: 4, // Tom
        createdById: 1,
        dueDate: tomorrow,
        recurring: 'weekly',
        sendReminder: true
      },
      {
        title: 'Clean bathroom (shower, toilet, sink)',
        description: 'Deep clean the bathroom, including shower, toilet and sink',
        householdId,
        assignedToId: 3, // Sarah
        createdById: 1,
        dueDate: thursday,
        recurring: 'weekly',
        sendReminder: true
      },
      {
        title: 'Stock kitchen supplies (paper towels, soap)',
        description: 'Check and restock paper towels, dish soap, and other kitchen supplies',
        householdId,
        assignedToId: 1, // Emma
        createdById: 1,
        dueDate: saturday,
        recurring: 'monthly',
        sendReminder: true
      }
    ];
    
    tasks.forEach(task => {
      const id = this.taskId++;
      this.tasks.set(id, {
        ...task,
        id,
        completed: false,
        completedAt: undefined,
        completedById: undefined,
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 1 week ago
      });
    });
    
    // Create some activities
    const activities = [
      {
        userId: 2, // Alex
        householdId,
        type: 'task_completed',
        taskId: 2,
        metadata: { taskTitle: 'Wash dishes and clean sink' }
      },
      {
        userId: 3, // Sarah
        householdId,
        type: 'task_created',
        taskId: 4,
        metadata: { taskTitle: 'Deep clean refrigerator' }
      },
      {
        userId: 4, // Tom
        householdId,
        type: 'task_completed',
        taskId: 3,
        metadata: { taskTitle: 'Mop kitchen and dining area' }
      }
    ];
    
    // Create activities with different timestamps
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000);
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const twoDaysAgo = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
    
    const timestamps = [twoHoursAgo, yesterday, twoDaysAgo];
    
    activities.forEach((activity, index) => {
      const id = this.activityId++;
      this.activities.set(id, {
        ...activity,
        id,
        createdAt: timestamps[index]
      });
    });
  }
}

export const storage = new MemStorage();
